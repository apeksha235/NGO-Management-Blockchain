# React client

This react project is unopinionated with only `web3.js` as an added dependency, so nothing stands in your way.

## Getting started

Run `npm start` to start the dev server, and `npm build` to create a production build.
